let Product = {
    sale: "Wheel Entine Sale",
    name: "PakWheels Waterless & Glass Cleaner",
    originalPrice: 1198,
    discount: "20%",
    discountedPrice: 958
};

console.log(Product);
