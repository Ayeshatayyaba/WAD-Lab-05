let a = 10;
console.log("Original value of a: " + a);
// Post-Increment (a++)
console.log("After a++: " + (a++)); 
console.log("Value of a now: " + a);  
// Pre-Increment (++a)
console.log("After ++a: " + (++a)); 
// Post-Decrement (a--)
console.log("After a--: " + (a--));  
console.log("Value of a now: " + a);  
// Pre-Decrement (--a)
console.log("After --a: " + (--a));  