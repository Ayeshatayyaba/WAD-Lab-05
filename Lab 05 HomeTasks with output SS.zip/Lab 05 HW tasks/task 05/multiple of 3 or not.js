let num = prompt("Enter a number:");

if (num % 3 == 0) {
    console.log(num + " is a multiple of 3.");
} else {
    console.log(num + " is NOT a multiple of 3.");
}
