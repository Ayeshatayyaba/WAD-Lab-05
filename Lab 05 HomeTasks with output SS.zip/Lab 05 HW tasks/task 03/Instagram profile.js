const InstagramProfile = {
    username: "aye_sham007",
    name: "Ayesha Tayyaba 🖤",
    posts: 0,
    followers: 96,
    following: 96,
    bio: "Pakistani 🇵🇰 But Dill Se Turkish. 🇹🇷\nI am the main character, this is my life <3"
};

console.log(InstagramProfile);
