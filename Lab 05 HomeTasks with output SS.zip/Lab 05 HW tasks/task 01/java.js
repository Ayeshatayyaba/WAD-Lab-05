let bigNumber = 12345678901234567890n;  
console.log(typeof bigNumber);  

let doubleNumber = bigNumber * 2n; 
console.log(doubleNumber); 
let mySymbol = Symbol("uniqueKey");  
console.log(typeof mySymbol);  

let student = {
  name: "Ayesha",
  [mySymbol]: "Secret Info"  
};

console.log(student.name);  
console.log(student[mySymbol]);  
