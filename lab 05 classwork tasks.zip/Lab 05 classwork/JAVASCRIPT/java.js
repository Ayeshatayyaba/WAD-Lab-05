console.log("Web APP dEV");
fullName="Tony stark";
age=20;
price=99.99;
radius=14;
a=null;
y=undefined;
console.log(fullName);