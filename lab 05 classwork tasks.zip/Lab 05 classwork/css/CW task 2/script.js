var name = "Nayab";
console.log(name); // Output: Nayab

var name = "Ali"; // Redeclaring allowed
console.log(name); // Output: Ali

name = "Sara"; // Updating allowed
console.log(name); // Output: Sara

if (true) {
    var test = "Inside block";
}
console.log(test); 
