let age = 25;
console.log(age); // Output: 25

age = 30; // Updating allowed
console.log(age); // Output: 30

if (true) {
    let insideBlock = "Hello";
    console.log(insideBlock); // Output: Hello
}
// console.log(insideBlock); 
