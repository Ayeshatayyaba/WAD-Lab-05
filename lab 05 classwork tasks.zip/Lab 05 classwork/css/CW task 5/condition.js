let score = 80;
if (score >= 50) {
    console.log("Pass");
} else {
    console.log("Fail");
}
for (let i = 0; i < 5; i++) {
    console.log("Iteration: " + i);
}
